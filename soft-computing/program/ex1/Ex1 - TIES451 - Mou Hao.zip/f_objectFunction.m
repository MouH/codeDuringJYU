function value = f_objectFunction(x)    
% ObjectFunction should be changed with different optimization problem

% x is two dimensional data
value = ( x(1)^2 + x(2) - 11 )^2 + ( x(2)^2 + x(1) -7 )^2;

end 